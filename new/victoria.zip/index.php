<?php
include "base/header.php";
include "page/home.php";
include "base/bottom.php"
 ?>
