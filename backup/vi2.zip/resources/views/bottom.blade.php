<script src="{{ URL::asset('js/jquery-1.8.3.min.js') }}"></script>
<script src="{{ URL::asset('js/bootstrap.min.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/hover-dropdown.js') }}"></script>
<script defer src="{{ URL::asset('js/jquery.flexslider.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/bxslider/jquery.bxslider.js') }}"></script>

<script type="text/javascript" src="{{ URL::asset('js/jquery.parallax-1.1.3.js') }}"></script>
<script src="{{ URL::asset('js/wow.min.js') }}"></script>
<script src="{{ URL::asset('assets/owlcarousel/owl.carousel.js') }}"></script>

<script src="{{ URL::asset('js/jquery.easing.min.js') }}"></script>
<script src="{{ URL::asset('js/link-hover.js') }}"></script>
<script src="{{ URL::asset('js/superfish.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/parallax-slider/jquery.cslider.js') }}"></script>
<script type="text/javascript">
  $(function() {

    $('#da-slider').cslider({
      autoplay    : true,
      bgincrement : 0
    });

  });
</script>



<!--common script for all pages-->
<script src="{{ URL::asset('js/common-scripts.js') }}">
</script>

<script type="text/javascript">
  jQuery(document).ready(function() {


    $('.bxslider1').bxSlider({
      minSlides: 5,
      maxSlides: 6,
      slideWidth: 360,
      slideMargin: 2,
      moveSlides: 1,
      responsive: true,
      nextSelector: '#slider-next',
      prevSelector: '#slider-prev',
      nextText: 'Onward →',
      prevText: '← Go back'
    });

  });


</script>


<script>
  $('a.info').tooltip();

  $(window).load(function() {
    $('.flexslider').flexslider({
      animation: "fade",
      start: function(slider) {
        $('body').removeClass('loading');
      }
    });
    $('.flexslider2').flexslider({
      animation: "fade",
      start: function(slider) {
        $('body').removeClass('loading');
      }
    });
  });

  $(document).ready(function() {

    $("#owl-demo").owlCarousel({

      items : 4

    });

  });

  jQuery(document).ready(function(){
    jQuery('ul.superfish').superfish();
  });

  new WOW().init();

  $("iframe").contents().find(".fade-box h2").css("font-size", "30px");
</script>
