@section('head')
<div class="row">
  <div class="col-md-8">
    <a class="navbar-brand" href="index.html">
      <img src="{{ URL::asset('assets/img/logo.png') }}">
    </a>
</div>
<div class="col-md-4">
<div class="btn-lang">
  <?php
  $url=$_SERVER['SERVER_NAME'];
  $req_url=$_SERVER['REQUEST_URI'];
  ?>
<a href="/id<? echo $req_url;?>" class="lang">Indonesia</a>
<a href="/en<? echo $req_url;?>" class="lang">English</a>
</div>
<div class="btn-group">
<a class="btn btn-primary dropdown-toggle menu" data-toggle="dropdown" href="#">
</a>
<ul class="dropdown-menu">
  @foreach($menu as $nav)
<li><a href="/{{$nav->url}}">{{$nav->MenuName}}</a></li>
@endforeach
</ul>
</div>
</div>
</div>
@stop
