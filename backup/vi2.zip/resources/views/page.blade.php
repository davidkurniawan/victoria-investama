@extends('page_template')
@extends('top_head')
@extends('head')
@extends('footer')
@extends('bottom')
@section('widget_saham')
<!-- STOCKTRADER.ORG.UK LIVE STOCK TICKER 1 START -->

<!-- STOCKTRADER.ORG.UK LIVE STOCK TICKER 1 END -->
@stop
