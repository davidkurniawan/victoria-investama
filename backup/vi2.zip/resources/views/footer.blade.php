@section('footer')
<div class="col-md-12 footer-white ">
  <div class="col-lg-2 col-sm-2 no-padding">
    <div class="page-footer wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
      <h5>
        Company
      </h5>
      <ul class="page-footer-list">
        <li>
          <a href="about.html">About Victoria</a>
        </li>
        <li>
          <a href="faq.html">Milestone</a>
        </li>
        <li>
          <a href="service.html">SO Structure</a>
        </li>
        <li>
          <a href="privacy-policy.html">Board of Directors</a>
        </li>
        <li>
          <a href="career.html">Supporting Institution</a>
        </li>
        <li>
          <a href="terms.html">Organization Structure</a>
        </li>
      </ul>
    </div>
  </div>

  <div class="col-lg-1 col-sm-2 no-padding">
    <div class="page-footer wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
      <h5>
        Services
      </h5>
      <ul class="page-footer-list">
        <li>
          <a href="about.html">Overview</a>
        </li>
      </ul>
    </div>
  </div>
  <div class="col-lg-2 col-sm-2 no-padding">
    <div class="page-footer wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
      <h5>
        Investor Relation
      </h5>
      <ul class="page-footer-list">
        <li>
          <a href="about.html">About Us</a>
        </li>
        <li>
          <a href="faq.html">Support</a>
        </li>
        <li>
          <a href="service.html">Service</a>
        </li>
        <li>
          <a href="privacy-policy.html">Privacy Policy</a>
        </li>
        <li>
          <a href="career.html">We are Hiring</a>
        </li>
        <li>
          <a href="terms.html">Term & condition</a>
        </li>
      </ul>
    </div>
  </div>
  <div class="col-lg-3 col-sm-3 no-padding">
    <div class="page-footer wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
      <h5>
        Corporate Social Responsibility
      </h5>






      <ul class="page-footer-list">
        <li>
          <a href="about.html">Good Coorporate Governance</a>
        </li>
        <li>
          <a href="faq.html">Audit Committee Charter</a>
        </li>
        <li>
          <a href="service.html">Audit Committee</a>
        </li>
        <li>
          <a href="privacy-policy.html">Remuneritation & Nomitaion Committee</a>
        </li>
        <li>
          <a href="career.html">General Meetings of Shareholder</a>
        </li>
        <li>
          <a href="terms.html">Term & condition</a>
        </li>
      </ul>
    </div>
  </div>
  <div class="col-lg-2 col-sm-2 no-padding">
    <div class="page-footer wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
      <h5>
        Media Room
      </h5>
      <ul class="page-footer-list">
        <li>
          <a href="about.html">About Us</a>
        </li>
        <li>
          <a href="faq.html">Support</a>
        </li>
        <li>
          <a href="service.html">Service</a>
        </li>
        <li>
          <a href="privacy-policy.html">Privacy Policy</a>
        </li>
        <li>
          <a href="career.html">We are Hiring</a>
        </li>
        <li>
          <a href="terms.html">Term & condition</a>
        </li>
      </ul>
    </div>
  </div>
  <div class="col-lg-2 col-sm-2 no-padding">
    <div class="page-footer wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
      <h5>
        Connect
      </h5>
      <ul class="page-footer-list">
        <li>
          <a href="about.html">About Us</a>
        </li>
        <li>
          <a href="faq.html">Support</a>
        </li>
        <li>
          <a href="service.html">Service</a>
        </li>
        <li>
          <a href="privacy-policy.html">Privacy Policy</a>
        </li>
        <li>
          <a href="career.html">We are Hiring</a>
        </li>
        <li>
          <a href="terms.html">Term & condition</a>
        </li>
      </ul>
    </div>
  </div>
  <div class="clearfix"></div>
  <div class="copyright">
    <img src="{{ URL::asset('assets/img/logo_gray.png') }}">
    <p>&copy; Copyright - Orijin Digital.</p>
  </div>
</div>
@stop
