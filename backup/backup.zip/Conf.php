<?php
    $mysqli = new mysqli("localhost","admvictoria_root","mi7260021","admvictoria_victoria");

    ini_set('display_errors', 1);

    if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
    }
?>