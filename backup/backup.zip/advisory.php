<div class='content-title'>Advisory</div>
<div style='margin-top: 10px;line-height: 16px;'>
	<p>	<img src='img/advisory.jpg' alt='Advisory' style='float: left;padding-right: 13px;'/>
		<b style='color: #fff;'>Pre-IPO Restructuring Advisory</b><br/>
		Victoria Investama can assist in restructuring
		clients business in order to maximize shareholder value. </p>

	<p style='margin-top: 13px;'> <b style='color: #fff;'>Merger & Acquisition Advisory Services</b><br/>
		We provide full services related to mergers and acquisitions, as well as divestitures. </p>
</div>