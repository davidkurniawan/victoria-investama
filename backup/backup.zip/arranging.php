<div class='content-title'>Arranger</div>
<div style='margin-top: 10px;line-height: 16px;'>
	<p>	<img src='img/arranging.jpg' alt='Arranging' style='float: left;padding-right: 13px;'/>
		Victoria Investama is able to arrange funds from the syndication of debt or other financial instruments from many financial institutions.
		 </p>


</div>