<div class='content-title'>Corporate Milestone</div>
<div style='margin-top: 10px;line-height: 16px;'>
	<img src='img/milestone-1.png' alt='Corporate Milestone' title='Corporate Milestone' style='margin-left: 20px;padding-bottom: 0px;' />
</div>