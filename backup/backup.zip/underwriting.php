<div class='content-title'>Underwriting</div>
<div style='margin-top: 10px;line-height: 16px;'>
	<p>	<img src='img/underwriting.jpg' alt='Underwriting' style='float: left;padding-right: 13px;'/>
		Our team of professionals is devoted to providing clients with the most effective range 
		of services to raise capital through IPO and arrange financing through debt market. 
		They firmly believe that a thorough understanding of the client's business and industry 
		is critical to effectively position the company to maximize its value.</p>
	
	<p style='margin-top: 13px;'> Our commitment to clients in IPO's extends well into the secondary market, 
		where we provide advisory support for future corporate action to enhance shareholder value.</p>
</div>