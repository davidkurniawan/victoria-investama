<div class='content-title'>Vision</div>
<div style='margin-top: 10px;line-height: 16px;'>
	<p>	Being an internationally scale top-tier investment company and providing one stop financial service solutions that are trustworthy through its subsidiaries.</p>
</div>
<div class='content-title' style='margin-top: 13px;'>Mission</div>
<div style='margin-top: 10px;line-height: 16px;'>
	<p> 
- Investing in companies that have good prospects in order to maximize its shareholders' value; <br>
- Providing services and up-to date information in the field of integrated financial services for customers;<br>
- Encourage sustainable development of human resources.<br>
</p>
</div>