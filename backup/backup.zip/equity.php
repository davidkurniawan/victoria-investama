<div class='content-title'>Equity</div>
<div style='margin-top: 10px;line-height: 16px;'>
	<p>	<img src='img/equity.jpg' alt='Equity' style='float: left;padding-right: 13px;'/>
		PT. Victoria Investama offers corporate and individual investors direct access to a wide range of stocks,
		including those listed on both the Jakarta Stock Exchage and the Surabaya Stock Exchange.
		The Steady rise of our market share over the years reflects our active involvement in the equity market. </p>

	<p style='margin-top: 13px;'> Our experienced and skilled team is committed to delivering quality services to our client base,
		and drawing upon our comprehensive and well-structured information system,
		provides up-to-date information on investment portofolio position.</p>

	<p style='margin-top: 13px;'> With Remote Trading System, our opportunity for growth in equity trading is virtualyy unlimited.</p>
</div>