<div class='content-title'>Vision</div>
<div style='margin-top: 10px;line-height: 16px;'>
	<p>	Victoria Investama is solution to your financial needs.</p>
</div>
<div class='content-title' style='margin-top: 13px;'>Mission</div>
<div style='margin-top: 10px;line-height: 16px;'>
	<p> To provide a complete and trustworthy services in financial advisory and arrager business.</p>
</div>