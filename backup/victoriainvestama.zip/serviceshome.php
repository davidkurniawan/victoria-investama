<!--<div style='margin-top: 3px;font: bold 13px Tahoma;color: #af0e0e;'>BROKERAGE</div>
<div style='margin-top: 3px;text-align: justify;'>
	<img src='img/market-board.jpg' alt='Market Board' align='top' style='float: left;margin-top: 3px;padding-right: 10px;' />
	Brokerage is a business that acts as a broker. A brokerage firm is a business that specializes in trading stocks.
	<ul style='list-style: none;margin: 3px;padding-left: 15px;padding-top: 0;'>
		<li>- Equity</a></li>
		<li>- Fixed Income</a></li>
	</ul>
</div>
-->
<div style='margin-top: 10px;font: bold 13px Tahoma;color: #af0e0e;'>CORPORATE FINANCE</div>
<div style='min-height: 70px;margin-top: 3px;text-align: justify;'>
	<img src='img/CorporateFinance.jpg' alt='Market Board' align='top' style='float: left;margin-top: 3px;padding-right: 10px;' />
	The primary goal of corporate finance is to maximize
	corporate value  while managing the firm's financial risks.
	<ul style='list-style: none;margin: 3px;padding-left: 15px;padding-top: 0;'>
		<li>- Advisory</a></li>
<!--		<li>- Underwriting</a></li>
-->		<li>- Arranging</a></li>
	</ul>
</div>