<div class='content-back'>
    <div class='content-title'>
         Web Modules
    </div>
    <div class='' style="margin-top: 150px;padding-left: 100px;font: bold 42px 'Brush Script MT', cursive;color: #777777;">
            " an access <br />
             <span style='margin-left: 50px;'>through the exchange."</span>
    </div>
</div>
