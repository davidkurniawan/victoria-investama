<?php
    $mysqli = new mysqli("localhost","root","","victoria");

    ini_set('display_errors', 1);

    if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
    }
?>