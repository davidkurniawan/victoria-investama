<!-- STOCKTRADER.ORG.UK LIVE STOCK TICKER 1 START -->
<script type="text/javascript">	
var wt = '5000';
var w = '250';
var h = '225';
var bgc = '000';
var tf = 'arial';
var tfs = '14';
var tc = '2E64DF';
var tbc = 'E0EADF';
var f = 'arial';
var fc = 'FFF';
var fs = '11';
var c = 'US';
var tz = '7';
var cw = '^STOXX50E,^IXIC,^GSPC,^FTSE,^GDAXI,^FCHI,^N225,^HSI,^STI,MSFT';

</script>
<script type="text/javascript" src="http://www.stocktrader.org.uk/remote2/ST1-1.php"></script>
<small style='color: #fff;'>Powered by <a href="http://www.stocktrader.org.uk" title="Stock Trader" target="_blank" style='color: blue;text-decoration: none;'>Stock Trader</a></small>
<!-- STOCKTRADER.ORG.UK LIVE STOCK TICKER 1 END -->