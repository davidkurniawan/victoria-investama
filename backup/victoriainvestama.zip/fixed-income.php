<div class='content-title'>Fixed Income</div>
<div style='margin-top: 10px;'>
	<p>	<img src='img/fix-income.jpg' alt='Fixed Income' style='float: left;padding-right: 13px;'/>
		PT. Victoria Investama aims to be one of the major players in the fixed income market.
		Our in depth knowledge of the market and vast distribution network enable us
		to provide clients with opportunity in trading bonds, domestic bank NCDs, promissory notes,
		commercial papers, medium term notes and FRN.</p>

	<p style='margin-top: 13px;'> Our marketing team consist of solid professionals with expertise in fixed income
		instruments and trading with both local and international investors.</p>
</div>