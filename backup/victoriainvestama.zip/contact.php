<div class='main-konten'>
	<div class='center_col' style='min-height: 225px;'>
		<div class='kolom' style='width: 600px;margin-top: 25px;'>
			<div class='content-title'>Contact</div>
			<div class='kolom-content'>
				<form action="mailto:you@yourdmainhere.com" method="post" enctype="text/plain">
				<table id='contact-form'>
					<tbody valign='top'>
						<tr>
							<td><b>Name :</b><br/><input class='textbox' type="text" name="name" /></td>
							<td rowspan='3'>
								<b>Message :</b><br/>
								<textarea name="message" style="width: 295px;height: 90px;"></textarea>
								<br />
								<input class='button' type='submit' name='send' value='Send' />
							</td>
						</tr>
						<tr>
							<td><b>Email :</b><br/><input class='textbox' type="text" name="email" /></td>
						</tr>
						<tr>
							<td><b>Subject :</b><br/><input class='textbox' type="text" name="subject" /></td>
						</tr>
					</tbody>
				</table>
				</form>
			</div>
		</div>
		<div class='kolom' style='width: 275px;'>
			<div class='kolom-content'>
				<div style='background: url(img/bc.gif);font: bold 13px arial,tahoma, serif;color: #fff;text-align: center;line-height: 22px;'>
					PT. Victoria Investama
				</div>
				<div style='margin-bottom: 2px;padding: 7px;font: 11px arial;'>
					Victoria Suites, Senayan City<br/>
					Panin Tower 8th Floor<br/>
					Jl. Asia Afrika Lot 19, Jakarta 10270<br/>
				</div>
				<div style='margin-bottom: 2px;padding: 7px;font: 11px arial;line-height: 16px;'>
					<b style='width: 40px;padding-right: 8px'>Phone</b> : +62 21 7278 2287 (General)<br/>
				</div>
				<div style='margin-bottom: 2px;padding: 7px;font: 11px arial;'>
					<b style='width: 40px;padding-right: 25px'>Fax</b> : +62 21 7278 2287
				</div>
				<div style='margin-bottom: 2px;padding: 7px;font: 11px arial;'>
					<b style='width: 40px;padding-right: 14px'>Email</b> :
					<a style='font-weight: normal;color: #1A5BFF;text-decoration: none;' href="mailto:support@victoria.co.id">cs@victoriaInvestama.co.id</a>
				</div>
			</div>
		</div>
	</div>
</div>
<div class='main-konten'>
	<div class='center_col' style='min-height: 100px;'>
		<img src='img/contact.png' class='pageimg' alt='About Victoria Sekuritas' />
	</div>
	<div class='clear'></div>
</div>