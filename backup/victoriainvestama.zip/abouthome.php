<div class='content-title'>Corporate Overview</div>
<div style='margin-top: 10px;line-height: 16px;'>
	<p>	The Company was first established in 1989 as PT. Tata Sekuritas Maju,
		a member of the Jakarta Stock Exchange, subsequently becoming a member of the Surabaya Stock Exchange in 1999.</p>

	<p style='margin-top: 13px;'>	The founders of the enterprise had successfully forged ahead trough the financial crisis holding to
		the vision of it becoming indonesia's premier financial service organization, providing unparalleled integrated
		services in brokerage and corporate finance areas.<br/>
		In line with a new and broadened vision, the Company then changed its name to PT. Victoria Sekuritas in 2000.<p>

	<p style='margin-top: 13px;'>	Our services are executed in a highly-qualified team of professionals dedicated to consistently deliver quality
		services toilored to meet client's needs.<p>

	<p style='margin-top: 13px;'>	PT. Victoria Investama believes that its strong capital structure, solid expertise and good corporate governance
		(following strict adherence to compliance standarts) are keys to providing our valued client base with unparalled service.<p>
</div>