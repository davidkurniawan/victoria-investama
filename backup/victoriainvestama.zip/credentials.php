<div class='content-title'>Credentials</div>
<div style='margin-top: 10px;line-height: 16px;'>
	<img src='img/credentials.jpg' alt='Credentials of Victoria Sekuritas' />
</div>