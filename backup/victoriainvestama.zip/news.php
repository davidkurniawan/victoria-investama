<?php
    include_once 'Conf.php';
    include_once 'component/Information/class/Information.class.php';
    include_once 'component/Information/class/InformationAdapter.class.php';

    $informationadapter = new InformationAdapter();
    $informationdata = $informationadapter->GetDataAsObject($mysqli);
?>

<div class='main-konten'>
	<div class='center_col'>
		<div class='kolom'>
			<div class='content-title'>Latest Market News</div>
			<div class='kolom-content'>
				<div id='news'>
					<ul>
						<?php
							foreach ($informationdata as $obj) {
							echo "<li>";
							echo "	<b class='news-date'>", date("D, d M Y",strtotime($obj->GetDate())) ,"</b><br/>";
							echo "	<div id='". $obj->GetNewsId() ."'><a class='news-title' href='#'>", $obj->GetTitle() ,"</a></div>";
							echo "</li>";
							}
						?>
					</ul>
				</div>
			</div>
		</div>
		<div class='kolom' style='width: 390px;background: url(img/dash.gif) repeat-y right top;'>
			<div class='content-title'><h2>Announcement</h2></div>
			<div class='kolom-content'>
				<h3>Notice To Customers</h3>
				<b class='news-date'>19 June 2012</b><br/>
				<div style='margin-top: 10px;'>
					Announcement to all customers, PT Victoria Sekuritas, on 19 June 2012 changed name to PT Victoria Investama
				</div>
			</div>
		</div>
		<div class='kolom'>
			<div class='content-title'>World Index</div>
			<div class='kolom-content'>
				<iframe src="word-index.php" style='width: 250px;height: 275px;border: 0;margin-top: -7px;margin-left: -5px;' scrolling='no'></iframe>
			</div>
		</div>
		<div class='clear'></div>
	</div>
</div>
<div class='main-konten'>
	<div class='center_col' style='min-height: 100px;'>
		<img src='img/news.png' class='pageimg' alt='News Victoria Sekuritas' />
	</div>
	<div class='clear'></div>
</div>
<script type="text/javascript">
	var curpage = "";

    function StartLoading()
    {
            loading = new Boxy("<div align='center'><img src='img/loading.gif' alt='loading' /></div>",{
                            title: "Loading Page",
                            closeable:false,
                            modal: true
            });
    }

     $(".news-title").click(function(){
		curpage = "news";
		var id = $(this).parents().attr("id");

			StartLoading();

            $.ajax({

                    url: "news-title.php",
                    type : "POST",
					data: "ID=" + escape(id),
                    success : function(result){
                            $("#content").empty().append(result);
                            loading.hideAndUnload();
                    }
            });
     })
</script>