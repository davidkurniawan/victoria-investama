<div class='main-konten'>
	<div class='center_col' style='min-height: 225px;'>
		<div class='kolom' style='width: 300px;'>
			<div class='content-title'>Info Memo</div>
			<div class='kolom-content'>
				<ul class='list'>
					<li><a href='lib/info-memo/Analisa_Obligasi_FIF_Tahun_2010.pdf'>Analisa Obligasi Federal International Finance</a></li>
					<li><a href='lib/info-memo/Analisa_Obligasi_Bank_Sulut.pdf'>Analisa Obligasi Bank Sulut</a></li>
					<li><a href='lib/info-memo/Analisa_Pembangunan_Perumahan.pdf'>Analisa Pembangunan Perumahan</a></li>
					<li><a href='lib/info-memo/Analisa_Saham_Sarana_Menara_Nusantara.pdf'>Analisa Saham Sarana Menara Nusantara</a></li>
				</ul>
			</div>
		</div>
<!--		<div class='kolom' style='width: 300px;'>
			<div class='content-title'>Opening Account Form</div>
			<div class='kolom-content'>
				<ul class='list'>
					<li><a href='lib/opening-account/Formulir_openrek_perorangan.pdf'>Formulir Pembukaan Rekening Perseorangan</a></li>
					<li><a href='lib/opening-account/Formulir_openrek_perusahaan.pdf'>Formulir Pembukaan Rekening Institusi/Perusahaan</a></li>
					<li><a href='lib/opening-account/Perjanjian_opening_acc.pdf'>Perjanjian Pembukaan Rekening Efek</a></li>
				</ul>
			</div>
		</div>-->
	</div>
</div>
<div class='main-konten'>
	<div class='center_col' style='min-height: 100px;'>
		<img src='img/download.png' class='pageimg' alt='About Victoria Sekuritas' />
	</div>
	<div class='clear'></div>
</div>