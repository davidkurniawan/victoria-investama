<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\menu;
use App\sidemenu;
use App\content;
use App\bod;
use Illuminate\Support\Facades\Redirect;
class WebController extends Controller
{
    //
    public function redirectpage($lang,$curlang,$page,$subpage)
    {
      return Redirect::to($lang.'/'.$page.'/'.$subpage);
    }
    public function index()
    {
      $menu=menu::Where('Parent','=','0')->get();
      return view('home',compact('menu'));
    }
    public function page($page)
    {
      $base_url=$_SERVER['SERVER_NAME'].'/'.$page;
      $menu=menu::Where('Parent','=','0')
      ->get();
      $default_menu=menu::Where('Parent','=','1')
      ->orderBy('MenuName', 'asc')
      ->first();
        return Redirect::to($page.'/'.$default_menu->url);
    }
    public function subpage($page,$subpage)
    {

      $base_url=$_SERVER['SERVER_NAME'].'/'.$page;
      $menu=menu::Where('Parent','=','0')->get();
      $parent_menu=sidemenu::find($page);
      $sidebar_menu=menu::Where('Parent','=',$parent_menu->id)->get();
      $title_nav=str_replace("-"," ",$subpage);
      $nav_title=ucfirst($title_nav);
      if($subpage=="about-victoria")
      {
      $content=content::find($subpage);
      return view('page',compact('menu','sidebar_menu','parent_menu','nav_title','base_url','content'));
      }
      if($subpage=="board-of-directors")
      {
      $content=content::find($subpage);
      $bod=bod::all();
      return view('page',compact('menu','sidebar_menu','parent_menu','nav_title','base_url','bod','content'));
      }

    }

}
