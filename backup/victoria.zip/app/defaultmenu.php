<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class defaultmenu extends Model
{
    //
    protected $table='menu';
    protected $primaryKey = 'url';
}
