<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class TableBOD extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bod', function (Blueprint $table) {
            $table->increments('id');
            $table->string('Name');
            $table->string('Position');
            $table->string('DescriptionID');
            $table->string('DescriptionEN');
            $table->string('Photo');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('bod');
    }
}
