<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Developed By M Abdur Rokib Promy">
    <meta name="author" content="cosmic">
    <meta name="keywords" content="Bootstrap 3, Template, Theme, Responsive, Corporate, Business">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>
      Victoria Investama
    </title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/theme.css" rel="stylesheet">
    <link href="css/bootstrap-reset.css" rel="stylesheet">
    <!-- <link href="css/bootstrap.min.css" rel="stylesheet">-->

    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/flexslider.css"/>
    <link href="assets/bxslider/jquery.bxslider.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="assets/owlcarousel/owl.carousel.css">
    <link rel="stylesheet" href="assets/owlcarousel/owl.theme.css">

    <link href="css/superfish.css" rel="stylesheet" media="screen">
    <link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
    <!-- <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'> -->


    <!-- Custom styles for this template -->
    <link rel="stylesheet" type="text/css" href="css/component.css">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />

    <link rel="stylesheet" type="text/css" href="css/parallax-slider/parallax-slider.css" />
    <script type="text/javascript" src="js/parallax-slider/modernizr.custom.28468.js">
    </script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js">
    </script>
    <script src="js/respond.min.js">
    </script>
    <![endif]-->
  </head>

  <body>
    <!--header start-->
    <header class="head-section">
      <div class="navbar navbar-default navbar-static-top container">
          <div class="navbar-header">
              <button class="navbar-toggle" data-target=".navbar-collapse" data-toggle="collapse" type="button">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="index.html">
                <img src="assets/img/logo.png ">
              </a>
          </div>
          <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">




                  <li class="dropdown">
                      <a class="dropdown-toggle" data-close-others="false" data-delay="0" data-hover=
                      "dropdown" data-toggle="dropdown" href="#">Blog <i class="fa fa-angle-down"></i>
                      </a>
                      <ul class="dropdown-menu">
                          <li>
                              <a href="blog.html">Blog</a>
                          </li>
                          <li>
                              <a href="blog-two-col.html">Blog two column</a>
                          </li>
                          <li>
                              <a href="blog-detail.html">Blog Single Image</a>
                          </li>
                          <li>
                              <a href="blog-detail-video.html">Blog single video</a>
                          </li>
                      </ul>
                  </li>
              </ul>
          </div>
      </div>
    </header>
    <!--header end-->

    <!-- Sequence Modern Slider -->
    <section class="slider wow fadeInRight">
      <div class="flexslider">
        <ul class="slides about-flex-slides">
          <li>
            <div class="about-testimonial-image ">
              <img alt="" src="assets/img/banner1.png">
            </div>
          </li>
          <li>
            <div class="about-testimonial-image ">
              <img alt="" src="assets/img/banner2.png">
            </div>


          </li>
        </ul>
      </div>
    </section>





    <!--property start-->
      <div class="container">
        <div class="home-text">

          <div class="col-lg-12 col-sm-12 wow fadeInRight">
            <p>
              The Company was established in 1989 as PT Tata Sekuritas Maju. In line with a new and broadened vision, the Company then changed its name to PT Victoria Sekuritas in 2000. In 2012 the Company reinvented itself becoming an investment holding company under the name of PT Victoria Investama and since 8 July 2013, the Company listed in Indonesia Stock Exchange and sold its share under the ticker code VICO.

            </p>
            <a href="javascript:;" class="btn btn-purchase">
              READ MORE
            </a>
          </div>
        </div>
      </div>

    <div class="container">
      <div class="row mar-b-50">
        <div class="col-md-4 ui-sortable no-padding-right">
            <section class="panel panel-red" id="panel-1" data-portlet-item=""  style="min-height:250px">
								<header class="panel-heading portlet-handler">
									<div class="panel-actions">
										<a href="#" class="panel-action panel-action-toggle" data-panel-toggle=""></a>
										<a href="#" class="panel-action panel-action-dismiss" data-panel-dismiss=""></a>
									</div>

									<h2 class="panel-title">Title</h2>
								</header>
								<div class="panel-body  dark">
                  <ul class="bxslider">
                    <?php echo $__env->yieldContent('widget_saham'); ?>

          </ul>
              	</div>
							</section>
          <!--feature end-->
        </div>
        <div class="col-md-4 ui-sortable no-padding">
            <section class="panel panel-red" id="panel-1" data-portlet-item=""  style="min-height:250px">
								<header class="panel-heading portlet-handler">
									<div class="panel-actions">
										<a href="#" class="panel-action panel-action-toggle" data-panel-toggle=""></a>
										<a href="#" class="panel-action panel-action-dismiss" data-panel-dismiss=""></a>
									</div>

									<h2 class="panel-title">Title</h2>
								</header>
								<div class="panel-body red">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur non imperdiet nisi. Quisque cursus leo et lacus tempus porttitor. Sed egestas laoreet justo non feugiat.
								</div>
							</section>
          <!--feature end-->
        </div>
        <div class="col-md-4 ui-sortable no-padding-left">
            <section class="panel panel-red" id="panel-1" data-portlet-item=""  style="min-height:250px">
								<header class="panel-heading portlet-handler">
									<div class="panel-actions">
										<a href="#" class="panel-action panel-action-toggle" data-panel-toggle=""></a>
										<a href="#" class="panel-action panel-action-dismiss" data-panel-dismiss=""></a>
									</div>

									<h2 class="panel-title">Title</h2>
								</header>
								<div class="panel-body">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur non imperdiet nisi. Quisque cursus leo et lacus tempus porttitor. Sed egestas laoreet justo non feugiat.
								</div>
							</section>
          <!--feature end-->
        </div>
      </div>
    </div>
    <!--property end-->




      <!--recent work start-->


    <!-- service end -->
    <!--container end-->

    <!--footer start-->
    <footer class="footer">
      <div class="container">
        <div class="col-md-12 footer-white ">
          <div class="col-lg-2 col-sm-2 no-padding">
            <div class="page-footer wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
              <h5>
                Company
              </h5>
              <ul class="page-footer-list">
                <li>
                  <a href="about.html">About Victoria</a>
                </li>
                <li>
                  <a href="faq.html">Milestone</a>
                </li>
                <li>
                  <a href="service.html">SO Structure</a>
                </li>
                <li>
                  <a href="privacy-policy.html">Board of Directors</a>
                </li>
                <li>
                  <a href="career.html">Supporting Institution</a>
                </li>
                <li>
                  <a href="terms.html">Organization Structure</a>
                </li>
              </ul>
            </div>
          </div>

          <div class="col-lg-2 col-sm-2 no-padding">
            <div class="page-footer wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
              <h5>
                Services
              </h5>
              <ul class="page-footer-list">
                <li>
                  <a href="about.html">Overview</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-2 col-sm-2 no-padding">
            <div class="page-footer wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
              <h5>
                Investor Relation
              </h5>
              <ul class="page-footer-list">
                <li>
                  <a href="about.html">About Us</a>
                </li>
                <li>
                  <a href="faq.html">Support</a>
                </li>
                <li>
                  <a href="service.html">Service</a>
                </li>
                <li>
                  <a href="privacy-policy.html">Privacy Policy</a>
                </li>
                <li>
                  <a href="career.html">We are Hiring</a>
                </li>
                <li>
                  <a href="terms.html">Term & condition</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-2 col-sm-2 no-padding">
            <div class="page-footer wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
              <h5>
                Corporate Social Responsibility
              </h5>






              <ul class="page-footer-list">
                <li>
                  <a href="about.html">Good Coorporate Governance</a>
                </li>
                <li>
                  <a href="faq.html">Audit Committee Charter</a>
                </li>
                <li>
                  <a href="service.html">Audit Committee</a>
                </li>
                <li>
                  <a href="privacy-policy.html">Remuneritation & Nomitaion Committee</a>
                </li>
                <li>
                  <a href="career.html">General Meetings of Shareholder</a>
                </li>
                <li>
                  <a href="terms.html">Term & condition</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-2 col-sm-2 no-padding">
            <div class="page-footer wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
              <h5>
                Media Room
              </h5>
              <ul class="page-footer-list">
                <li>
                  <a href="about.html">About Us</a>
                </li>
                <li>
                  <a href="faq.html">Support</a>
                </li>
                <li>
                  <a href="service.html">Service</a>
                </li>
                <li>
                  <a href="privacy-policy.html">Privacy Policy</a>
                </li>
                <li>
                  <a href="career.html">We are Hiring</a>
                </li>
                <li>
                  <a href="terms.html">Term & condition</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-2 col-sm-2 no-padding">
            <div class="page-footer wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
              <h5>
                Connect
              </h5>
              <ul class="page-footer-list">
                <li>
                  <a href="about.html">About Us</a>
                </li>
                <li>
                  <a href="faq.html">Support</a>
                </li>
                <li>
                  <a href="service.html">Service</a>
                </li>
                <li>
                  <a href="privacy-policy.html">Privacy Policy</a>
                </li>
                <li>
                  <a href="career.html">We are Hiring</a>
                </li>
                <li>
                  <a href="terms.html">Term & condition</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="copyright">
            <img src="assets/img/logo_gray.png">
            <p>&copy; Copyright - Acme Theme by cosmic.</p>
          </div>
        </div>
      </div>
    </footer>
    <!-- footer end -->
    <!--small footer start -->

    <!--small footer end-->

    <!-- js placed at the end of the document so the pages load faster
<script src="js/jquery.js">
</script>
-->
    <script src="js/jquery-1.8.3.min.js">
    </script>
    <script src="js/bootstrap.min.js">
    </script>
    <script type="text/javascript" src="js/hover-dropdown.js">
    </script>
    <script defer src="js/jquery.flexslider.js">
    </script>
    <script type="text/javascript" src="assets/bxslider/jquery.bxslider.js">
    </script>

    <script type="text/javascript" src="js/jquery.parallax-1.1.3.js">
    </script>
    <script src="js/wow.min.js">
    </script>
    <script src="assets/owlcarousel/owl.carousel.js">
    </script>

    <script src="js/jquery.easing.min.js">
    </script>
    <script src="js/link-hover.js">
    </script>
    <script src="js/superfish.js">
    </script>
    <script type="text/javascript" src="js/parallax-slider/jquery.cslider.js">
    </script>
    <script type="text/javascript">
      $(function() {

        $('#da-slider').cslider({
          autoplay    : true,
          bgincrement : 0
        });

      });
    </script>



    <!--common script for all pages-->
    <script src="js/common-scripts.js">
    </script>

    <script type="text/javascript">
      jQuery(document).ready(function() {


        $('.bxslider1').bxSlider({
          minSlides: 5,
          maxSlides: 6,
          slideWidth: 360,
          slideMargin: 2,
          moveSlides: 1,
          responsive: true,
          nextSelector: '#slider-next',
          prevSelector: '#slider-prev',
          nextText: 'Onward →',
          prevText: '← Go back'
        });

      });


    </script>


    <script>
      $('a.info').tooltip();

      $(window).load(function() {
        $('.flexslider').flexslider({
          animation: "slide",
          start: function(slider) {
            $('body').removeClass('loading');
          }
        });
      });

      $(document).ready(function() {

        $("#owl-demo").owlCarousel({

          items : 4

        });

      });

      jQuery(document).ready(function(){
        jQuery('ul.superfish').superfish();
      });

      new WOW().init();


    </script>
  </body>
</html>
