



<?php $__env->startSection('widget_saham'); ?>
<!-- STOCKTRADER.ORG.UK LIVE STOCK TICKER 1 START -->

<!-- STOCKTRADER.ORG.UK LIVE STOCK TICKER 1 END -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('top_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('home_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>