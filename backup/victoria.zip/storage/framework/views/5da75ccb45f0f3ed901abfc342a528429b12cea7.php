<?php $__env->startSection('head'); ?>
<div class="row">
  <div class="col-md-8">
    <a class="navbar-brand" href="index.html">
      <img src="assets/img/logo.png ">
    </a>
</div>
<div class="col-md-4">
<div class="btn-lang">
<a href="/id" class="lang">Indonesia</a>
<a href="/en" class="lang">English</a>
</div>
<div class="btn-group">
<a class="btn btn-primary dropdown-toggle menu" data-toggle="dropdown" href="#">
</a>
<ul class="dropdown-menu">
<li><a href="#">Company</a></li>
<li><a href="#">Services</a></li>
<li><a href="#">Investor Relation</a></li>
  <li><a href="#">CSR</a></li>
    <li><a href="#">Media</a></li>
    <li><a href="#">Connect Us</a></li>
</ul>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
