<?php foreach( $objYahooStock->getQuotes() as $code => $stock): ?>
        <li>
      Name: <?php echo e($stock[1]); ?> <br />
      Code: <?php echo e($stock[0]); ?> <br />
      Last Trade Price: <?php echo e($stock[2]); ?> <br />
      Last Trade Date: <?php echo e($stock[3]); ?> <br />
      Last Trade Time: <?php echo e($stock[4]); ?> <br />
      Change and Percent Change: <?php echo e($stock[5]); ?> <br />
      Volume: <?php echo e($stock[6]); ?> <br /><br />
      </li>
<?php endforeach; ?>
