@section('top_head')
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Developed By M Abdur Rokib Promy">
<meta name="author" content="cosmic">
<meta name="keywords" content="Bootstrap 3, Template, Theme, Responsive, Corporate, Business">
<link rel="shortcut icon" href="img/favicon.png">

<title>
  Victoria Investama
</title>

<!-- Bootstrap core CSS -->
<link href="{{ URL::asset('css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ URL::asset('css/theme.css') }}" rel="stylesheet">
<link href="{{ URL::asset('css/bootstrap-reset.css') }}" rel="stylesheet">
<!-- <link href="css/bootstrap.min.css" rel="stylesheet">-->

<!--external css-->
<link href="{{ URL::asset('assets/font-awesome/css/font-awesome.css') }}" rel="stylesheet" />
<link rel="stylesheet" href="{{ URL::asset('css/flexslider.css') }}"/>
<link href="{{ URL::asset('assets/bxslider/jquery.bxslider.css" rel="stylesheet') }}" />
<link rel="stylesheet" href="{{ URL::asset('css/animate.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/owlcarousel/owl.carousel.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/owlcarousel/owl.theme.css') }}">
<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
<link href="{{ URL::asset('css/superfish.css') }}" rel="stylesheet" media="screen">
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<!-- <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'> -->


<!-- Custom styles for this template -->
<link rel="stylesheet" type="text/css" href="{{ URL::asset('css/component.css') }}">
<link href="{{ URL::asset('css/style.css') }}" rel="stylesheet">
<link href="{{ URL::asset('css/style-responsive.css') }}" rel="stylesheet" />

<link rel="stylesheet" type="text/css" href="{{ URL::asset('css/parallax-slider/parallax-slider.css') }}" />
<script type="text/javascript" src="{{ URL::asset('js/parallax-slider/modernizr.custom.28468.js') }}">
</script>

<!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
<!--[if lt IE 9]>
<script src="js/html5shiv.js">
</script>
<script src="js/respond.min.js">
</script>
<![endif]-->
@stop
