@foreach( $objYahooStock->getQuotes() as $code => $stock)
        <li>
      Name: {{$stock[1]}} <br />
      Code: {{$stock[0]}} <br />
      Last Trade Price: {{$stock[2]}} <br />
      Last Trade Date: {{$stock[3]}} <br />
      Last Trade Time: {{$stock[4]}} <br />
      Change and Percent Change: {{ $stock[5]}} <br />
      Volume: {{$stock[6]}} <br /><br />
      </li>
@endforeach
