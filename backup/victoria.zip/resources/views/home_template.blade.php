<!DOCTYPE html>
<html lang="en">
  <head>
@yield('top_head')
  </head>

  <body>
    <!--header start-->
    <header class="head-section">
      <div class="container">
      @yield('head')
    </div>
    </header>
    <!--header end-->

    <!-- Sequence Modern Slider -->
    <section class="slider">
      <div class="flexslider">
        <ul class="slides about-flex-slides">
          <li>
            <div class="about-testimonial-image ">
              <img alt="" src="assets/img/banner1.png">
            </div>
          </li>
        </ul>
        <!--
        <div class="container box-banner">
          <div class="col-md-2 box-slider">
            Test
          </div>
          <div class="col-md-2 box-slider">
            Test
          </div>
          <div class="col-md-2 box-slider">
            Test
          </div>
        </div>
      -->
      </div>

    </section>





    <!--property start-->
      <div class="container">
        <div class="home-text">

          <div class="col-lg-12 col-sm-12 wow fadeInRight">
            <p>
              The Company was established in 1989 as PT Tata Sekuritas Maju. In line with a new and broadened vision, the Company then changed its name to PT Victoria Sekuritas in 2000. In 2012 the Company reinvented itself becoming an investment holding company under the name of PT Victoria Investama and since 8 July 2013, the Company listed in Indonesia Stock Exchange and sold its share under the ticker code VICO.
            </p>
            <a href="javascript:;" class="btn btn-purchase">
              READ MORE
            </a>
          </div>
        </div>
      </div>

    <div class="container">
      <div class="row mar-b-50">
        <div class="col-md-4 ui-sortable no-padding-right">
            <section class="panel panel-red" id="panel-1" data-portlet-item=""  style="min-height:250px">
								<header class="panel-heading portlet-handler">
									<div class="panel-actions">
										<a href="#" class="panel-action panel-action-toggle" data-panel-toggle=""></a>
										<a href="#" class="panel-action panel-action-dismiss" data-panel-dismiss=""></a>
									</div>

									<h2 class="panel-title">Bursa Saham</h2>
								</header>
								<div class="panel-body  dark">
                  <script type="text/javascript">
                  var wt = '5000';
                  var w = '250';
                  var h = '170';
                  var bgc = '171717';
                  var tf = 'arial';
                  var tfs = '14';
                  var tc = 'ffffff';
                  var tbc = '171717';
                  var f = 'arial';
                  var fc = 'fff';
                  var fs = '15';
                  var c = 'US';
                  var tz = '0';
                  var cw = '^STOXX50E,^IXIC,^GSPC,^FTSE,^GDAXI,^FCHI,^N225,^HSI,^STI,MSFT';

                  </script>

                  <script type="text/javascript" src="http://www.stocktrader.org.uk/remote2/ST1-1.php"></script>
              	</div>
							</section>
          <!--feature end-->
        </div>
        <div class="col-md-4 ui-sortable no-padding">
            <section class="panel panel-red" id="panel-1" data-portlet-item=""  style="min-height:250px">
								<header class="panel-heading portlet-handler">
									<div class="panel-actions">
										<a href="#" class="panel-action panel-action-toggle" data-panel-toggle=""></a>
										<a href="#" class="panel-action panel-action-dismiss" data-panel-dismiss=""></a>
									</div>

									<h2 class="panel-title">Title</h2>
								</header>
								<div class="panel-body red">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur non imperdiet nisi. Quisque cursus leo et lacus tempus porttitor. Sed egestas laoreet justo non feugiat.
								</div>
							</section>
          <!--feature end-->
        </div>
        <div class="col-md-4 ui-sortable no-padding-left">
            <section class="panel panel-red" id="panel-1" data-portlet-item=""  style="min-height:250px">
								<header class="panel-heading portlet-handler">
									<div class="panel-actions">
										<a href="#" class="panel-action panel-action-toggle" data-panel-toggle=""></a>
										<a href="#" class="panel-action panel-action-dismiss" data-panel-dismiss=""></a>
									</div>

									<h2 class="panel-title">Title</h2>
								</header>
								<div class="panel-body">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur non imperdiet nisi. Quisque cursus leo et lacus tempus porttitor. Sed egestas laoreet justo non feugiat.
								</div>
							</section>
          <!--feature end-->
        </div>
      </div>
    </div>
    <!--property end-->




      <!--recent work start-->


    <!-- service end -->
    <!--container end-->

    <!--footer start-->
    <footer class="footer">
      <div class="container">
        @yield('footer')
      </div>
    </footer>
    <!-- footer end -->
    <!--small footer start -->

    <!--small footer end-->

    <!-- js placed at the end of the document so the pages load faster
<script src="js/jquery.js">
</script>
-->
    <script src="js/jquery-1.8.3.min.js">
    </script>
    <script src="js/bootstrap.min.js">
    </script>
    <script type="text/javascript" src="js/hover-dropdown.js">
    </script>
    <script defer src="js/jquery.flexslider.js">
    </script>
    <script type="text/javascript" src="assets/bxslider/jquery.bxslider.js">
    </script>

    <script type="text/javascript" src="js/jquery.parallax-1.1.3.js">
    </script>
    <script src="js/wow.min.js">
    </script>
    <script src="assets/owlcarousel/owl.carousel.js">
    </script>

    <script src="js/jquery.easing.min.js">
    </script>
    <script src="js/link-hover.js">
    </script>
    <script src="js/superfish.js">
    </script>
    <script type="text/javascript" src="js/parallax-slider/jquery.cslider.js">
    </script>
    <script type="text/javascript">
      $(function() {

        $('#da-slider').cslider({
          autoplay    : true,
          bgincrement : 0
        });

      });
    </script>



    <!--common script for all pages-->
    <script src="js/common-scripts.js">
    </script>

    <script type="text/javascript">
      jQuery(document).ready(function() {


        $('.bxslider1').bxSlider({
          minSlides: 5,
          maxSlides: 6,
          slideWidth: 360,
          slideMargin: 2,
          moveSlides: 1,
          responsive: true,
          nextSelector: '#slider-next',
          prevSelector: '#slider-prev',
          nextText: 'Onward →',
          prevText: '← Go back'
        });

      });


    </script>


    <script>
      $('a.info').tooltip();

      $(window).load(function() {
        $('.flexslider').flexslider({
          animation: "fade",
          start: function(slider) {
            $('body').removeClass('loading');
          }
        });
        $('.flexslider2').flexslider({
          animation: "fade",
          start: function(slider) {
            $('body').removeClass('loading');
          }
        });
      });

      $(document).ready(function() {

        $("#owl-demo").owlCarousel({

          items : 4

        });

      });

      jQuery(document).ready(function(){
        jQuery('ul.superfish').superfish();
      });

      new WOW().init();

      $("iframe").contents().find(".fade-box h2").css("font-size", "30px");
    </script>
  </body>
</html>
